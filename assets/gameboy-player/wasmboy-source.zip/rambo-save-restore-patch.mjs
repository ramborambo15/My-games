import fs from 'node:fs';import assert from 'node:assert/strict';import crypto from 'node:crypto';
const base='work/wasmboy/package/dist';
const original=fs.readFileSync(base+'/core/core.untouched.wasm');
const patched=Buffer.from(original);
const wat=fs.readFileSync(base+'/core/core.untouched.wat','utf8');
const globals=[...wat.matchAll(/^ \(global \$([^ ]+)/gm)].map(x=>x[1]);
function leb(value){const bytes=[];do{let byte=value&127;value>>>=7;if(value)byte|=128;bytes.push(byte);}while(value);return bytes;}
function uniquePattern(pattern,label){const at=patched.indexOf(pattern);assert(at>=0,label);assert.equal(patched.indexOf(pattern,at+1),-1,`${label} must be unique`);return at;}
function patchSource(source,before,after){
 const text=fs.readFileSync(source,'utf8'),oldCount=text.split(before).length-1,newCount=text.split(after).length-1;
 assert(oldCount===1&&newCount===0||oldCount===0&&newCount===1,`Unique source statement: ${before}`);
 fs.writeFileSync(source,oldCount?text.replace(before,after):text);
}
for(let channel=1;channel<=4;channel++){
 const globalIndex=globals.indexOf(`core/sound/channel${channel}/Channel${channel}.cycleCounter`);assert(globalIndex>=0);
 const pattern=Buffer.from([0x23,...leb(globalIndex),0x41,0x32,0x6c,0x41,0x80,0x08,0x6a,0x28,0x02,0]);
 const at=uniquePattern(pattern,`channel ${channel} load-state pattern`);
 // Replace global.get cycleCounter with i32.const saveStateSlot. Pad with nop to retain byte offsets.
 const replacement=[0x41,6+channel];while(replacement.length<1+leb(globalIndex).length)replacement.push(0x01);
 patched.set(replacement,at);
 const source=`work/wasmboy-upstream/wasmboy-8e96bcb70969d943b1ffc4028b169c835098ce04/core/sound/channel${channel}.ts`;
 patchSource(source,`Channel${channel}.cycleCounter = load<i32>(getSaveStateMemoryOffset(0x00, Channel${channel}.cycleCounter));`,`Channel${channel}.cycleCounter = load<i32>(getSaveStateMemoryOffset(0x00, Channel${channel}.saveStateSlot));`);
}
// Restore LY from the graphics save partition rather than using the current LY as a partition index.
{
 const globalIndex=globals.indexOf('core/graphics/graphics/Graphics.scanlineRegister');assert(globalIndex>=0);
 const pattern=Buffer.from([0x23,...leb(globalIndex),0x41,0x32,0x6c,0x41,0x84,0x08,0x6a,0x2d,0x00,0x00,0x24,...leb(globalIndex)]);
 const at=uniquePattern(pattern,'graphics scanline load-state pattern');
 const replacement=[0x41,0x01];while(replacement.length<1+leb(globalIndex).length)replacement.push(0x01);
 patched.set(replacement,at);
 patchSource('work/wasmboy-upstream/wasmboy-8e96bcb70969d943b1ffc4028b169c835098ce04/core/graphics/graphics.ts',
  'Graphics.scanlineRegister = load<u8>(getSaveStateMemoryOffset(0x04, Graphics.scanlineRegister));',
  'Graphics.scanlineRegister = load<u8>(getSaveStateMemoryOffset(0x04, Graphics.saveStateSlot));');
}
// The original sweep loads are narrower than their matching saves. Change opcodes/alignment in place.
for(const [name,address,opcode,alignment,offset,type]of [
 ['sweepCounter',1416,0x28,0x02,'0x2a','i32'],
 ['sweepShadowFrequency',1420,0x2f,0x01,'0x2e','u16']
]){
 const globalIndex=globals.indexOf(`core/sound/channel1/Channel1.${name}`);assert(globalIndex>=0);
 const prefix=[0x41,...leb(address)];
 const pattern=Buffer.from([...prefix,0x2d,0x00,0x00,0x24,...leb(globalIndex)]);
 const at=uniquePattern(pattern,`channel 1 ${name} load-state pattern`);
 patched.set([opcode,alignment,0x00],at+prefix.length);
 patchSource('work/wasmboy-upstream/wasmboy-8e96bcb70969d943b1ffc4028b169c835098ce04/core/sound/channel1.ts',
  `Channel1.${name} = load<u8>(getSaveStateMemoryOffset(${offset}, Channel1.saveStateSlot));`,
  `Channel1.${name} = load<${type}>(getSaveStateMemoryOffset(${offset}, Channel1.saveStateSlot));`);
}
assert.equal(patched.length,original.length,'In-place patches preserve all module byte offsets');
assert(WebAssembly.validate(patched));
const original64=original.toString('base64'),patched64=patched.toString('base64');
for(const format of ['esm','cjs']){
 const originalBundle=fs.readFileSync(`${base}/wasmboy.wasm.${format}.js`,'utf8');let replaced=0;
 const bundle=originalBundle.replace(/data:application\/javascript;base64,([A-Za-z0-9+/=]+)/g,(match,encoded)=>{
  const worker=Buffer.from(encoded,'base64').toString();if(!worker.includes(original64))return match;
  replaced++;return 'data:application/javascript;base64,'+Buffer.from(worker.split(original64).join(patched64)).toString('base64');
 });assert.equal(replaced,1);
 fs.writeFileSync(format==='esm'?'work/rambo-arcade/assets/gameboy-player/wasmboy.js':'work/wasmboy-patched.cjs',bundle);
}
fs.writeFileSync('work/wasmboy-patched.wasm',patched);
console.log('Patched four audio-channel counter slots, graphics scanline slot, and two sweep load widths. WASM validated; byte offsets preserved.');
console.log('Upstream SHA256',crypto.createHash('sha256').update(original).digest('hex'));
console.log('Patched SHA256',crypto.createHash('sha256').update(patched).digest('hex'));
