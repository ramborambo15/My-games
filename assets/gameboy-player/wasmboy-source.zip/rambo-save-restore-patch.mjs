import fs from 'node:fs';import assert from 'node:assert/strict';import crypto from 'node:crypto';
const base='work/wasmboy/package/dist';
const original=fs.readFileSync(base+'/core/core.untouched.wasm');
const patched=Buffer.from(original);
const wat=fs.readFileSync(base+'/core/core.untouched.wat','utf8');
const globals=[...wat.matchAll(/^ \(global \$([^ ]+)/gm)].map(x=>x[1]);
function leb(value){const bytes=[];do{let byte=value&127;value>>>=7;if(value)byte|=128;bytes.push(byte);}while(value);return bytes;}
for(let channel=1;channel<=4;channel++){
 const globalIndex=globals.indexOf(`core/sound/channel${channel}/Channel${channel}.cycleCounter`);assert(globalIndex>=0);
 const pattern=Buffer.from([0x23,...leb(globalIndex),0x41,0x32,0x6c,0x41,0x80,0x08,0x6a,0x28,0x02,0]);
 const at=patched.indexOf(pattern);assert(at>=0,`channel ${channel} load-state pattern`);assert.equal(patched.indexOf(pattern,at+1),-1);
 // Replace global.get cycleCounter with i32.const saveStateSlot. Pad with nop to retain byte offsets.
 const replacement=[0x41,6+channel];while(replacement.length<1+leb(globalIndex).length)replacement.push(0x01);
 patched.set(replacement,at);
 const source=`work/wasmboy-upstream/wasmboy-8e96bcb70969d943b1ffc4028b169c835098ce04/core/sound/channel${channel}.ts`;
 const text=fs.readFileSync(source,'utf8');fs.writeFileSync(source,text.replace(`getSaveStateMemoryOffset(0x00, Channel${channel}.cycleCounter)`,`getSaveStateMemoryOffset(0x00, Channel${channel}.saveStateSlot)`));
}
assert(WebAssembly.validate(patched));
const original64=original.toString('base64'),patched64=patched.toString('base64');
for(const format of ['esm','cjs']){
 const originalBundle=fs.readFileSync(`${base}/wasmboy.wasm.${format}.js`,'utf8');let replaced=0;
 const bundle=originalBundle.replace(/data:application\/javascript;base64,([A-Za-z0-9+/=]+)/g,(match,encoded)=>{
  const worker=Buffer.from(encoded,'base64').toString();if(!worker.includes(original64))return match;
  replaced++;return 'data:application/javascript;base64,'+Buffer.from(worker.split(original64).join(patched64)).toString('base64');
 });assert.equal(replaced,1);
 fs.writeFileSync(format==='esm'?'work/rambo-arcade/assets/gameboy-player/wasmboy.js':'work/wasmboy-patched.cjs',bundle);
}
fs.writeFileSync('work/wasmboy-patched.wasm',patched);
console.log('Patched all four audio-channel counters during save restore. WASM validated.');
console.log('Upstream SHA256',crypto.createHash('sha256').update(original).digest('hex'));
console.log('Patched SHA256',crypto.createHash('sha256').update(patched).digest('hex'));
